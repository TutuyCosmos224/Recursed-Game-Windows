# Events

The official events are listed here:

+ [Text Event](./Events/000)
+ [Character Join](./Events/001)
+ [Character Leave](./Events/002)

<!-- If you want to make your own nodes you can read the guide here: -->